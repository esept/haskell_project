module Problem2 where

import EL

-- Interprétation des variables
interp :: Prop -> [World]
interp "as" = [10, 11]
interp "bs" = [01, 11]
interp _ = []

-- Indiscernibilité
indis :: Agent -> World -> [World]
indis "a" 00 = [00, 10]
indis "a" 10 = [00, 10]
indis "a" 01 = [01, 11]
indis "a" 11 = [01, 11]
indis "b" 00 = [00, 01]
indis "b" 01 = [00, 01]
indis "b" 10 = [10, 11]
indis "b" 11 = [10, 11]
indis _ _ = []

-- Initial state
s0 :: EpiState
s0 = (interp, indis, 11)

-- l'annonce du père
fatherAnn :: EpiFormula
fatherAnn = Or (Var "as") (Var "bs")

-- Alice est ignorante
aliceIgn :: EpiFormula
aliceIgn = And (Not (Knows "a" (Var "as"))) (Not (Knows "a" (Not (Var "as"))))

-- Bob est ignorant
bobIgn :: EpiFormula
bobIgn = And (Not (Knows "b" (Var "bs"))) (Not (Knows "b" (Not (Var "bs"))))

-- Problem 2
problem2 :: EpiFormula
problem2 =
  After
    ( After
        (And (fatherAnn) (And (aliceIgn) (bobIgn)))
        (And (aliceIgn) (bobIgn))
    )
    (And (Not aliceIgn) (Not bobIgn))