
Rendu : Episode 2

Membres du Groupe :

Traore Bernard : TD1 Groupe A
Zhaoyang Xu : TD1 Groupe A 
Kane Mouhamadou Abdoul : TD1 Groupe A


